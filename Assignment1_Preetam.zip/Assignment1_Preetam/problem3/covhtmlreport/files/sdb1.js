var g_db_data = {"20":1,"3":1,"4":1,"2":1,"1":1};
processScopesDbFile(g_db_data);