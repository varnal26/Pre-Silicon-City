var g_data = ["","testbench.sv","design.sv"];
processSrcNamesData(g_data);