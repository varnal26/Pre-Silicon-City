var g_data = {"21":[20,"and_add_xor",1],"22":[20,"mult",1],"20":[5,"DUT",1],"5":[-1,"top",1]};
processInstLinks(g_data);