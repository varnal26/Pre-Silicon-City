var g_data = {"3":["work.single_cycle",95.51,1],"4":["work.three_cycle",96.87,1],"2":["work.tinyalu",97.66,1],"1":["work.top",84.28,1]};
processDuLinks(g_data);